<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="author" content="Dapzgank.my.id" />
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description'); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/favicon.png')); ?>" />

    <meta name="description" content="" />
    <meta name="keywords" content="bootstrap, bootstrap5" />

    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600;700&display=swap"
        rel="stylesheet" />

    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/icomoon/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/flaticon/font/flaticon.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/tiny-slider.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/aos.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />

    <title><?php echo e($title); ?> - Puncak Permata Batu</title>
</head>

<body>
    <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
            <div class="site-mobile-menu-close">
                <span class="icofont-close js-menu-toggle"></span>
            </div>
        </div>
        <div class="site-mobile-menu-body"></div>
    </div>

    <?php if (isset($component)) { $__componentOriginal08cf8b3632d5e9dfc173bb3501abd94f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal08cf8b3632d5e9dfc173bb3501abd94f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.molecules.Navbar','data' => ['title' => $title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal08cf8b3632d5e9dfc173bb3501abd94f)): ?>
<?php $attributes = $__attributesOriginal08cf8b3632d5e9dfc173bb3501abd94f; ?>
<?php unset($__attributesOriginal08cf8b3632d5e9dfc173bb3501abd94f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08cf8b3632d5e9dfc173bb3501abd94f)): ?>
<?php $component = $__componentOriginal08cf8b3632d5e9dfc173bb3501abd94f; ?>
<?php unset($__componentOriginal08cf8b3632d5e9dfc173bb3501abd94f); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal64ee743414d14d0b2b31571df5eab708 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal64ee743414d14d0b2b31571df5eab708 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.molecules.Hero','data' => ['title' => $title,'banner' => $banner,'article' => $article ?? '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title),'banner' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($banner),'article' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($article ?? '')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal64ee743414d14d0b2b31571df5eab708)): ?>
<?php $attributes = $__attributesOriginal64ee743414d14d0b2b31571df5eab708; ?>
<?php unset($__attributesOriginal64ee743414d14d0b2b31571df5eab708); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal64ee743414d14d0b2b31571df5eab708)): ?>
<?php $component = $__componentOriginal64ee743414d14d0b2b31571df5eab708; ?>
<?php unset($__componentOriginal64ee743414d14d0b2b31571df5eab708); ?>
<?php endif; ?>

    <?php echo e($slot); ?>


    <?php if (isset($component)) { $__componentOriginal1a1b0b46746169d35e1b0264de6171df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1a1b0b46746169d35e1b0264de6171df = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.molecules.Footer','data' => ['title' => $title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1a1b0b46746169d35e1b0264de6171df)): ?>
<?php $attributes = $__attributesOriginal1a1b0b46746169d35e1b0264de6171df; ?>
<?php unset($__attributesOriginal1a1b0b46746169d35e1b0264de6171df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1a1b0b46746169d35e1b0264de6171df)): ?>
<?php $component = $__componentOriginal1a1b0b46746169d35e1b0264de6171df; ?>
<?php unset($__componentOriginal1a1b0b46746169d35e1b0264de6171df); ?>
<?php endif; ?>

    <!-- Preloader -->
    <div id="overlayer"></div>
    <div class="loader">
        <div class="spinner-border" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal965fd44620cd50664fa333234c0d7253 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal965fd44620cd50664fa333234c0d7253 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.atoms.Share','data' => ['title' => $title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Share'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal965fd44620cd50664fa333234c0d7253)): ?>
<?php $attributes = $__attributesOriginal965fd44620cd50664fa333234c0d7253; ?>
<?php unset($__attributesOriginal965fd44620cd50664fa333234c0d7253); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal965fd44620cd50664fa333234c0d7253)): ?>
<?php $component = $__componentOriginal965fd44620cd50664fa333234c0d7253; ?>
<?php unset($__componentOriginal965fd44620cd50664fa333234c0d7253); ?>
<?php endif; ?>

    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/tiny-slider.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/navbar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/counter.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
</body>

</html>
<?php /**PATH E:\Laravel\puncakpermatabatu\resources\views/components/templates/HomeLayout.blade.php ENDPATH**/ ?>