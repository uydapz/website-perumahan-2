<?php if (isset($component)) { $__componentOriginalb9460d71389dcd0ffb2a92a3ca86b86f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb9460d71389dcd0ffb2a92a3ca86b86f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.templates.DashboardLayout','data' => ['title' => $title ?? 'Properti']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('DashLayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title ?? 'Properti')]); ?>
    <script src="https://cdn.tiny.cloud/1/7v0ppq2eg2r7qq1bety6oavos0nqskl9ol3icyrxxmy1geh6/tinymce/8/tinymce.min.js"
        referrerpolicy="origin" crossorigin="anonymous"></script>
    <style>
        @media print {

            th:last-child,
            td:last-child,
            .no-print {
                display: none !important;
            }
        }
    </style>

    <div class="p-4 rounded shadow-sm">
        <?php if(session('success')): ?>
            <script>
                Swal.fire('Berhasil!', '<?php echo e(session('success')); ?>', 'success');
            </script>
        <?php endif; ?>

        <div class="d-flex justify-content-between mb-3">
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPropertiModal">
                + Tambah Properti
            </button>
            <button class="btn btn-outline-secondary" onclick="printTable()">🖨️ Print Semua</button>
        </div>

        <div class="table-responsive">
            <table id="TableFire" class="table table-bordered table-striped align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Thumbnail</th>
                        <th>Sample</th>
                        <th>Judul</th>
                        <th>Deskripsi</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="row-<?php echo e($a->id); ?>">
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php if($a->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $a->image)); ?>" width="80" class="rounded">
                                <?php else: ?>
                                    <span class="text-muted">Tidak ada gambar</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div style="display: flex; gap: 8px; align-items: center;">
                                    
                                    <?php $__currentLoopData = $a->gambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div style="text-align: center;">
                                            <img src="<?php echo e(asset('storage/' . $g->image)); ?>" width="40"
                                                style="border-radius: 4px;">
                                            <form action="<?php echo e(route('gambar.destroy', $g->id)); ?>" method="POST"
                                                onsubmit="return confirm('Hapus gambar ini?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button
                                                    style="background: none; border: none; color: red; font-size: 12px;">Hapus</button>
                                            </form>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </td>
                            <td><strong><?php echo e($a->title ?? '-'); ?></strong></td>
                            <td><?php echo $a->deskripsi; ?></td>
                            <td class="no-print">
                                <button class="btn btn-warning btn-sm" data-bs-toggle="modal"
                                    data-bs-target="#editArticlesModal<?php echo e($a->id); ?>">
                                    ✏️
                                </button>
                                <form action="<?php echo e(route('article.destroy', $a->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="button" onclick="confirmDelete(this.form)"
                                        class="btn btn-danger btn-sm">🗑️</button>
                                </form>
                                <button onclick="printRow('row-<?php echo e($a->id); ?>')"
                                    class="btn btn-outline-secondary btn-sm">
                                    🖨️
                                </button>
                            </td>
                        </tr>

                        <!-- Modal Edit -->
                        <div class="modal fade" id="editArticlesModal<?php echo e($a->id); ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form action="<?php echo e(route('article.update', $a->id)); ?>" method="POST"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <div class="modal-header">
                                            <h5 class="modal-title">Edit Properti</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <input type="text" name="title" class="form-control mb-2"
                                                placeholder="Judul" value="<?php echo e($a->title); ?>">
                                            <textarea type="text" name="deskripsi" class="form-control mb-2" placeholder="Deskripsi"><?php echo e($a->deskripsi); ?></textarea>
                                            <input type="file" name="image" class="form-control mb-2">
                                            <input type="file" name="gambar[]" multiple accept="image/*">
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Batal</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Tambah -->
    <div class="modal fade" id="addPropertiModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('article.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title">Tambah Properti</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="text" name="title" class="form-control mb-2" placeholder="Judul (opsional)">
                        <textarea type="text" name="deskripsi" class="form-control mb-2" placeholder="Deskripsi" required></textarea>
                        <input type="file" name="image" class="form-control mb-2">
                        <input type="file" name="gambar[]" multiple accept="image/*">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-success">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal259ea361df1e3733c53b34957b81b3e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal259ea361df1e3733c53b34957b81b3e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.atoms.Scriptadm','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Scriptadm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal259ea361df1e3733c53b34957b81b3e3)): ?>
<?php $attributes = $__attributesOriginal259ea361df1e3733c53b34957b81b3e3; ?>
<?php unset($__attributesOriginal259ea361df1e3733c53b34957b81b3e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal259ea361df1e3733c53b34957b81b3e3)): ?>
<?php $component = $__componentOriginal259ea361df1e3733c53b34957b81b3e3; ?>
<?php unset($__componentOriginal259ea361df1e3733c53b34957b81b3e3); ?>
<?php endif; ?>
    <script>
        function printTable() {
            const table = document.getElementById('TableFire').cloneNode(true);
            Array.from(table.rows).forEach(row => row.deleteCell(-1));
            const win = window.open('', '', 'height=600,width=800');
            win.document.write('<html><head><title>Daftar Properti</title>');
            win.document.write(
                '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" />'
            );
            win.document.write('</head><body><h4 class="text-center my-3">Daftar Properti</h4>');
            win.document.write(table.outerHTML);
            win.document.write('</body></html>');
            win.document.close();
            win.print();
        }

        function printRow(rowId) {
            const row = document.getElementById(rowId).cloneNode(true);
            row.deleteCell(-1);
            const win = window.open('', '', 'width=600,height=400');
            win.document.write('<html><head><title>Detail Properti</title>');
            win.document.write(
                '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" />'
            );
            win.document.write('</head><body><h4 class="text-center my-3">Detail Properti</h4>');
            win.document.write('<table class="table table-bordered"><tbody>' + row.outerHTML + '</tbody></table>');
            win.document.write('</body></html>');
            win.document.close();
            win.print();
        }

        tinymce.init({
            selector: 'textarea[name=deskripsi]', // atau ganti sesuai kebutuhan
            plugins: 'link image code lists',
            toolbar: 'undo redo | bold italic underline | alignleft aligncenter alignright | bullist numlist | link image | code',
            height: 300
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb9460d71389dcd0ffb2a92a3ca86b86f)): ?>
<?php $attributes = $__attributesOriginalb9460d71389dcd0ffb2a92a3ca86b86f; ?>
<?php unset($__attributesOriginalb9460d71389dcd0ffb2a92a3ca86b86f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9460d71389dcd0ffb2a92a3ca86b86f)): ?>
<?php $component = $__componentOriginalb9460d71389dcd0ffb2a92a3ca86b86f; ?>
<?php unset($__componentOriginalb9460d71389dcd0ffb2a92a3ca86b86f); ?>
<?php endif; ?>
<?php /**PATH E:\Laravel\puncakpermatabatu\resources\views/components/pages/Articles.blade.php ENDPATH**/ ?>