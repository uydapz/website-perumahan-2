<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title><?php echo e($title ?? ''); ?> | Dashboard</title>

    <!-- Icons & Fonts -->
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('admassets/img/apple-icon.png')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('admassets/img/favicon.png')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />

    <!-- Nucleo Icons -->
    <link href="<?php echo e(asset('admassets/css/nucleo-icons.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('admassets/css/nucleo-svg.css')); ?>" rel="stylesheet" />

    <!-- Main CSS -->
    <link href="<?php echo e(asset('admassets/css/argon-dashboard-tailwind.css?v=1.0.1')); ?>" rel="stylesheet" />

    <!-- DataTables Tailwind CSS -->
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.tailwindcss.min.css" rel="stylesheet" />

    <!-- Animate (optional) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Optional JS & SweetAlert -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>


</head>

<body
    class="m-0 font-sans text-base antialiased font-normal dark:bg-slate-900 leading-default bg-gray-50 text-slate-500">
    <style>
        a {
            text-decoration: none;
        }
    </style>

    <!-- Sidebar -->
    <?php if (isset($component)) { $__componentOriginal507acc29df5936dd2ca182eb101d90b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal507acc29df5936dd2ca182eb101d90b8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.molecules.Sidebaradm','data' => ['title' => $title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Sidebaradm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal507acc29df5936dd2ca182eb101d90b8)): ?>
<?php $attributes = $__attributesOriginal507acc29df5936dd2ca182eb101d90b8; ?>
<?php unset($__attributesOriginal507acc29df5936dd2ca182eb101d90b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal507acc29df5936dd2ca182eb101d90b8)): ?>
<?php $component = $__componentOriginal507acc29df5936dd2ca182eb101d90b8; ?>
<?php unset($__componentOriginal507acc29df5936dd2ca182eb101d90b8); ?>
<?php endif; ?>

    <!-- Main Content -->
    <main class="relative h-full max-h-screen transition-all duration-200 ease-in-out xl:ml-68 rounded-xl">
        <?php if (isset($component)) { $__componentOriginalba947b1b3902fc7f6cf7373af11c7b04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba947b1b3902fc7f6cf7373af11c7b04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.molecules.Navbaradm','data' => ['title' => $title ?? 'Dashboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Navbaradm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title ?? 'Dashboard')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba947b1b3902fc7f6cf7373af11c7b04)): ?>
<?php $attributes = $__attributesOriginalba947b1b3902fc7f6cf7373af11c7b04; ?>
<?php unset($__attributesOriginalba947b1b3902fc7f6cf7373af11c7b04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba947b1b3902fc7f6cf7373af11c7b04)): ?>
<?php $component = $__componentOriginalba947b1b3902fc7f6cf7373af11c7b04; ?>
<?php unset($__componentOriginalba947b1b3902fc7f6cf7373af11c7b04); ?>
<?php endif; ?>

        <!-- Page content slot -->
        <?php echo e($slot); ?>


        <?php if (isset($component)) { $__componentOriginalb0f0d6594592bdb5b81c3a2873d39f07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb0f0d6594592bdb5b81c3a2873d39f07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.molecules.Footeradm','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Footeradm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb0f0d6594592bdb5b81c3a2873d39f07)): ?>
<?php $attributes = $__attributesOriginalb0f0d6594592bdb5b81c3a2873d39f07; ?>
<?php unset($__attributesOriginalb0f0d6594592bdb5b81c3a2873d39f07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb0f0d6594592bdb5b81c3a2873d39f07)): ?>
<?php $component = $__componentOriginalb0f0d6594592bdb5b81c3a2873d39f07; ?>
<?php unset($__componentOriginalb0f0d6594592bdb5b81c3a2873d39f07); ?>
<?php endif; ?>
    </main>

    <!-- jQuery (required by DataTables) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Chart.js -->
    <script src="<?php echo e(asset('admassets/js/plugins/chartjs.min.js')); ?>"></script>

    <!-- Perfect Scrollbar -->
    <script src="<?php echo e(asset('admassets/js/plugins/perfect-scrollbar.min.js')); ?>"></script>

    <!-- Argon Dashboard Main JS -->
    <script src="<?php echo e(asset('admassets/js/argon-dashboard-tailwind.js?v=1.0.1')); ?>"></script>

    <!-- SweetAlert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.tailwindcss.min.js"></script>

    <!-- Page Specific Scripts (Slot) -->
    <?php if(isset($scripts)): ?>
        <?php echo e($scripts); ?>

    <?php endif; ?>
</body>

</html>
<?php /**PATH E:\Laravel\puncakpermatabatu\resources\views/components/templates/DashboardLayout.blade.php ENDPATH**/ ?>