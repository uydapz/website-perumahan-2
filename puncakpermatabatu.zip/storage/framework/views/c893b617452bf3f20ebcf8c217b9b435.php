<?php if (isset($component)) { $__componentOriginal9985ec6b6b9e688b8cf3289292c0591e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9985ec6b6b9e688b8cf3289292c0591e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.templates.HomeLayout','data' => ['title' => $title ?? '','banner' => $banner,'article' => $article]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('HomeLayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title ?? ''),'banner' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($banner),'article' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($article)]); ?>
    <?php $__env->startSection('meta_description', Str::limit(strip_tags($article->deskripsi ?? 'Deskripsi article'), 160)); ?>
    <div class="section">
        <div class="container">
            <div class="row justify-content-between">
                
                <div class="col-lg-7">
                    <div class="img-property-slide-wrap">
                        <div class="img-property-slide">
                            <?php $__empty_1 = true; $__currentLoopData = $article->gambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <img src="<?php echo e(asset('storage/' . $prop->image)); ?>"
                                    alt="Rumah di <?php echo e($article->address); ?> - <?php echo e($article->title); ?>"
                                    class="img-fluid mb-2" />
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <img src="<?php echo e(asset('images/default.jpg')); ?>"
                                    alt="Rumah di <?php echo e($article->address); ?> - <?php echo e($article->title); ?>" loading="lazy"
                                    class="img-fluid mb-2" />
                            <?php endif; ?>
                        </div>
                    </div>
                </div>


                
                <div class="col-lg-4">
                    <article class="property-detail">
                        <header>
                            <h1 class="heading text-primary"><?php echo e($article->title ?? 'Tanpa Judul'); ?></h1>
                            <p class="meta"><?php echo e($article->address); ?></p>
                        </header>
                        <p>
                            <?php echo e($article->deskripsi ?? 'Tanpa Deskripsi'); ?>

                        </p>
                    </article>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9985ec6b6b9e688b8cf3289292c0591e)): ?>
<?php $attributes = $__attributesOriginal9985ec6b6b9e688b8cf3289292c0591e; ?>
<?php unset($__attributesOriginal9985ec6b6b9e688b8cf3289292c0591e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9985ec6b6b9e688b8cf3289292c0591e)): ?>
<?php $component = $__componentOriginal9985ec6b6b9e688b8cf3289292c0591e; ?>
<?php unset($__componentOriginal9985ec6b6b9e688b8cf3289292c0591e); ?>
<?php endif; ?>
<?php /**PATH E:\Laravel\puncakpermatabatu\resources\views/components/pages/Articles-single.blade.php ENDPATH**/ ?>