<?php if (isset($component)) { $__componentOriginalb9460d71389dcd0ffb2a92a3ca86b86f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb9460d71389dcd0ffb2a92a3ca86b86f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.templates.DashboardLayout','data' => ['title' => $title ?? 'Beranda']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('DashLayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title ?? 'Beranda')]); ?>
    <div class="container p-4">
        <h1 class="mb-4">Statistik Dashboard</h1>
        
        <div class="row g-4">
            
            <div class="col-md-3">
                <div class="card shadow-sm bg-primary text-white">
                    <div class="card-body text-center">
                        <h6 class="mb-1">Total Users</h6>
                        <h2 class="mb-0"><?php echo e($total_users); ?></h2>
                    </div>
                </div>
            </div>

            
            <div class="col-md-3">
                <div class="card shadow-sm bg-success text-white">
                    <div class="card-body text-center">
                        <h6 class="mb-1">Total Banners</h6>
                        <h2 class="mb-0"><?php echo e($total_banners); ?></h2>
                    </div>
                </div>
            </div>

            
            <div class="col-md-3">
                <div class="card shadow-sm bg-warning text-dark">
                    <div class="card-body text-center">
                        <h6 class="mb-1">Total Artikel</h6>
                        <h2 class="mb-0"><?php echo e($total_articles); ?></h2>
                    </div>
                </div>
            </div>

            
            <div class="col-md-3">
                <div class="card shadow-sm bg-danger text-white">
                    <div class="card-body text-center">
                        <h6 class="mb-1">Total Testimoni</h6>
                        <h2 class="mb-0"><?php echo e($total_testimoni); ?></h2>
                    </div>
                </div>
            </div>

            
            <div class="col-md-12">
                <div class="card shadow-sm border-0">
                    <div class="card-body text-center">
                        <p class="mb-1">Rata-rata Bintang</p>
                        <h3 class="mb-0"><?php echo e($average_rating); ?> ⭐</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb9460d71389dcd0ffb2a92a3ca86b86f)): ?>
<?php $attributes = $__attributesOriginalb9460d71389dcd0ffb2a92a3ca86b86f; ?>
<?php unset($__attributesOriginalb9460d71389dcd0ffb2a92a3ca86b86f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9460d71389dcd0ffb2a92a3ca86b86f)): ?>
<?php $component = $__componentOriginalb9460d71389dcd0ffb2a92a3ca86b86f; ?>
<?php unset($__componentOriginalb9460d71389dcd0ffb2a92a3ca86b86f); ?>
<?php endif; ?>
<?php /**PATH E:\Laravel\puncakpermatabatu\resources\views/components/pages/dashboard.blade.php ENDPATH**/ ?>