<div class="hero">
    <div class="hero-slide">
        <?php if($title == 'Beranda' || $title == 'About Us'): ?>
            <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="img overlay" style="background-image: url('<?php echo e(asset('storage/' . $b->image)); ?>')"></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php elseif($title != 'Beranda' && $title != 'About Us'): ?>
            <div class="img overlay" style="background-image: url('<?php echo e(asset('storage/' . $article->image)); ?>')">
            </div>
        <?php endif; ?>
    </div>

    <?php if($title != 'Beranda' && $title != 'About Us'): ?>
        <div class="container">
            <div class="row justify-content-center align-items-center">
                <div class="col-lg-9 text-center mt-5">
                    <h1 class="heading" data-aos="fade-up">
                        <?php echo e($article->title); ?>

                    </h1>
                    <nav aria-label="breadcrumb" data-aos="fade-up" data-aos-delay="200">
                        <ol class="breadcrumb text-center justify-content-center">
                            <li class="breadcrumb-item"><a href="/">Home</a></li>
                            <li class="breadcrumb-item active text-white-50" aria-current="page">
                                <?php echo e($article->title); ?>

                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH E:\Laravel\puncakpermatabatu\resources\views/components/molecules/Hero.blade.php ENDPATH**/ ?>