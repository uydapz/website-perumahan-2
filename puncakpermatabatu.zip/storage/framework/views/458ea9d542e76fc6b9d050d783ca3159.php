 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
  
</head>

<body>

  <!-- Navbar -->
  <header class="navbar navbar-expand-lg navbar-dark sticky-top">
    <div class="container-fluid">
      <a class="navbar-brand fw-bold" href="#">PrimaLand</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item"><a class="nav-link active" href="#">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Our Project</a></li>
          <li class="nav-item"><a class="nav-link" href="#">About Us</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Join Us</a></li>
        </ul>
      </div>
    </div>
  </header>

  <main class="main">


  <!-- Hero Section -->
  <section class="hero-section d-flex align-items-center">
    <div class="container hero-content">
      <div class="row">
        <div class="col-md-7">
          <h2 class="hero-title">JURAGAN KOST</h2>
          <h1 class="hero-subtitle">2025</h1>
          <p class="hero-caption">“Duduk Santai Cuan Mengalir”</p>
        </div>
      </div>
    </div>
    <img src="assets/img/hero-character.png" alt="Juragan Kost" class="hero-image" />
  </section>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script><?php /**PATH E:\Laravel\puncakpermatabatu\resources\views/components/molecules/Header.blade.php ENDPATH**/ ?>