<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Properti Kelola Kami</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f5f5f5;
      font-family: 'Segoe UI', sans-serif;
    }

    .property-carousel {
      max-width: 700px;
      margin: 60px auto;
      background: white;
      border-radius: 16px;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
      padding: 20px;
    }

    .carousel-item {
      text-align: center;
      padding: 10px;
    }

    .property-img {
      max-width: 100%;
      height: 160px;
      object-fit: cover;
      border-radius: 12px;
      margin-bottom: 15px;
      box-shadow: 0 6px 14px rgba(0, 0, 0, 0.1);
    }

    .property-title {
      font-size: 1.25rem;
      font-weight: 700;
      color: #2c3e50;
      margin-bottom: 6px;
    }

    .property-desc {
      font-size: 0.95rem;
      color: #7f8c8d;
    }

    .carousel-control-prev,
    .carousel-control-next {
      filter: grayscale(1);
    }
  </style>
</head>
<body>

<div class="property-carousel">
  <h4 class="text-center mb-4">Properti yang Telah Kami Kelola</h4>
  <div id="carouselProperty" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">

      <div class="carousel-item active">
        <img src="assets/img/3.jpg" class="property-img" alt="Properti 1">
        <div class="property-title">Cluster Lavender</div>
        <div class="property-desc">Hunian modern dengan nuansa tropis dan fasilitas lengkap.</div>
      </div>

      <div class="carousel-item">
        <img src="assets/img/2.jpg" class="property-img" alt="Properti 2">
        <div class="property-title">Taman Melati Residence</div>
        <div class="property-desc">Perumahan nyaman di pusat kota, cocok untuk keluarga muda.</div>
      </div>

      <div class="carousel-item">
        <img src="assets/img/1.jpg" class="property-img" alt="Properti 3">
        <div class="property-title">The Hill View</div>
        <div class="property-desc">View perbukitan yang menenangkan dan udara sejuk alami.</div>
      </div>

    </div>

    <button class="carousel-control-prev" type="button" data-bs-target="#carouselProperty" data-bs-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselProperty" data-bs-slide="next">
      <span class="carousel-control-next-icon"></span>
    </button>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH E:\Laravel\puncakpermatabatu\resources\views/welcome.blade.php ENDPATH**/ ?>