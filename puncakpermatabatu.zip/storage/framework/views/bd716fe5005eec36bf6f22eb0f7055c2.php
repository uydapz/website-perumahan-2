<?php if (isset($component)) { $__componentOriginalb9460d71389dcd0ffb2a92a3ca86b86f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb9460d71389dcd0ffb2a92a3ca86b86f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.templates.DashboardLayout','data' => ['title' => $title ?? 'Properti']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('DashLayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title ?? 'Properti')]); ?>
    <style>
        @media print {
            th:last-child,
            td:last-child,
            .no-print {
                display: none !important;
            }
        }
    </style>

    <div class="p-4 rounded shadow-sm">
        <?php if(session('success')): ?>
            <script>
                Swal.fire('Berhasil!', '<?php echo e(session('success')); ?>', 'success');
            </script>
        <?php endif; ?>

        <div class="d-flex justify-content-between mb-3">
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPropertiModal">
                + Tambah Properti
            </button>
            <button class="btn btn-outline-secondary" onclick="printTable()">🖨️ Print Semua</button>
        </div>

        <div class="table-responsive">
            <table id="TableFire" class="table table-bordered table-striped align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Foto</th>
                        <th>Judul</th>
                        <th>Alamat</th>
                        <th>Harga</th>
                        <th>Rincian</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $properti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="row-<?php echo e($p->id); ?>">
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php if($p->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $p->image)); ?>" width="80" class="rounded">
                                <?php else: ?>
                                    <span class="text-muted">Tidak ada gambar</span>
                                <?php endif; ?>
                            </td>
                            <td><strong><?php echo e($p->title ?? '-'); ?></strong></td>
                            <td><?php echo e($p->address); ?></td>
                            <td>Rp<?php echo e(number_format($p->price, 0, ',', '.')); ?></td>
                            <td><?php echo e($p->beds); ?> 🛏 / <?php echo e($p->baths); ?> 🛁</td>
                            <td class="no-print">
                                <button class="btn btn-warning btn-sm" data-bs-toggle="modal"
                                    data-bs-target="#editPropertiModal<?php echo e($p->id); ?>">
                                    ✏️
                                </button>
                                <form action="<?php echo e(route('properti.destroy', $p->id)); ?>" method="POST"
                                    class="d-inline">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="button" onclick="confirmDelete(this.form)"
                                        class="btn btn-danger btn-sm">🗑️</button>
                                </form>
                                <button onclick="printRow('row-<?php echo e($p->id); ?>')"
                                    class="btn btn-outline-secondary btn-sm">
                                    🖨️
                                </button>
                            </td>
                        </tr>

                        <!-- Modal Edit -->
                        <div class="modal fade" id="editPropertiModal<?php echo e($p->id); ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form action="<?php echo e(route('properti.update', $p->id)); ?>" method="POST"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <div class="modal-header">
                                            <h5 class="modal-title">Edit Properti</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <input type="text" name="title" class="form-control mb-2" placeholder="Judul" value="<?php echo e($p->title); ?>">
                                            <input type="text" name="address" class="form-control mb-2" placeholder="Alamat" value="<?php echo e($p->address); ?>">
                                            <input type="number" name="price" class="form-control mb-2" placeholder="Harga" value="<?php echo e($p->price); ?>">
                                            <input type="number" name="beds" class="form-control mb-2" placeholder="Kamar Tidur" value="<?php echo e($p->beds); ?>">
                                            <input type="number" name="baths" class="form-control mb-2" placeholder="Kamar Mandi" value="<?php echo e($p->baths); ?>">
                                            <input type="file" name="image" class="form-control mb-2">
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Tambah -->
    <div class="modal fade" id="addPropertiModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('properti.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title">Tambah Properti</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="text" name="title" class="form-control mb-2" placeholder="Judul (opsional)">
                        <input type="text" name="address" class="form-control mb-2" placeholder="Alamat" required>
                        <input type="number" name="price" class="form-control mb-2" placeholder="Harga" required>
                        <input type="number" name="beds" class="form-control mb-2" placeholder="Kamar Tidur" required>
                        <input type="number" name="baths" class="form-control mb-2" placeholder="Kamar Mandi" required>
                        <input type="file" name="image" class="form-control mb-2">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-success">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal259ea361df1e3733c53b34957b81b3e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal259ea361df1e3733c53b34957b81b3e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.atoms.Scriptadm','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('Scriptadm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal259ea361df1e3733c53b34957b81b3e3)): ?>
<?php $attributes = $__attributesOriginal259ea361df1e3733c53b34957b81b3e3; ?>
<?php unset($__attributesOriginal259ea361df1e3733c53b34957b81b3e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal259ea361df1e3733c53b34957b81b3e3)): ?>
<?php $component = $__componentOriginal259ea361df1e3733c53b34957b81b3e3; ?>
<?php unset($__componentOriginal259ea361df1e3733c53b34957b81b3e3); ?>
<?php endif; ?>
    <script>
        function printTable() {
            const table = document.getElementById('TableFire').cloneNode(true);
            Array.from(table.rows).forEach(row => row.deleteCell(-1));
            const win = window.open('', '', 'height=600,width=800');
            win.document.write('<html><head><title>Daftar Properti</title>');
            win.document.write('<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" />');
            win.document.write('</head><body><h4 class="text-center my-3">Daftar Properti</h4>');
            win.document.write(table.outerHTML);
            win.document.write('</body></html>');
            win.document.close();
            win.print();
        }

        function printRow(rowId) {
            const row = document.getElementById(rowId).cloneNode(true);
            row.deleteCell(-1);
            const win = window.open('', '', 'width=600,height=400');
            win.document.write('<html><head><title>Detail Properti</title>');
            win.document.write('<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" />');
            win.document.write('</head><body><h4 class="text-center my-3">Detail Properti</h4>');
            win.document.write('<table class="table table-bordered"><tbody>' + row.outerHTML + '</tbody></table>');
            win.document.write('</body></html>');
            win.document.close();
            win.print();
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb9460d71389dcd0ffb2a92a3ca86b86f)): ?>
<?php $attributes = $__attributesOriginalb9460d71389dcd0ffb2a92a3ca86b86f; ?>
<?php unset($__attributesOriginalb9460d71389dcd0ffb2a92a3ca86b86f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9460d71389dcd0ffb2a92a3ca86b86f)): ?>
<?php $component = $__componentOriginalb9460d71389dcd0ffb2a92a3ca86b86f; ?>
<?php unset($__componentOriginalb9460d71389dcd0ffb2a92a3ca86b86f); ?>
<?php endif; ?><?php /**PATH E:\Laravel\puncakpermatabatu\resources\views/components/pages/properti.blade.php ENDPATH**/ ?>